﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading;

#region "VB与C#差异"

//1、
//VB中数组定义 dim a(2) as string, 数组的长度为3，下标从0~2；
//C#中数组定义 string[] a=new string[2]，数组的长度为2，下标从0~1；

//2、
//CR -- Carriage Return:回车， 用\r表示；
//LF -- Line Feed: 换行， 用\n表示;

//3、NetworkStatus_Menu.Image = global::PengDongNanTools.Properties.Resources.NoNetwork;

//4、System.Net.ServicePointManager.SetTcpKeepAlive(true, 1000, 1000);

//5、逻辑“与”	    x & y	    整型按位 AND，布尔逻辑 AND
     //逻辑 XOR	    x ^ y	    整型按位 XOR，布尔逻辑 XOR
     //逻辑 OR	    x | y	    整型按位 OR，布尔逻辑 OR
     //条件 AND	    x && y	    仅当 x 为 true 时，才对 y 求值
     //条件 OR	    x || y	    仅当 x 为 false 时，才对 y 求值
     //null 合并	X ?? y	    如果 x 为 null，则计算结果为 y，否则计算结果为 x
     //条件	        x ? y : z	如果 x 为 true，则对 y 求值；如果 x 为 false，则对 z 求值

     //移位	x << y	左移
     //     x >> y	右移

     //关系和类型检测
     //x is T	如果 x 为 T，则返回 true，否则返回 false
     //x as T	返回转换为类型 T 的 x，如果 x 不是 T 则返回 null

    //加减	x + y	加法、字符串串联、委托组合
	//      x – y	减法、委托移除

    //移位	x << y	左移
	//      x >> y	右移

    //乘法	x * y	乘法
	//      x / y	除法
	//      x % y	求余

    //一元	
    //    +x	    恒等
    //    -x	    求相反数
    //    !x	    逻辑求反
    //    ~x	    按位求反
    //    ++x	    前增量
    //    --x	    前减量
    //    (T)x	    将 x 显式转换为类型 T
    //    await x	异步等待 x 完成

    //基本	x.m	成员访问
    //    x(...)	        方法和委托调用
    //    x[...]	        数组和索引器访问
    //    x++	            后增量
    //    x--	            后减量
    //    new T(...)	    对象和委托创建
    //    new T(...){...}	使用初始值设定项创建对象
    //    new {...}	        匿名对象初始值设定项
    //    new T[...]	    数组创建
    //    typeof(T)	        获取 T 的 System.Type 对象
    //    checked(x)	    在 checked 上下文中计算表达式
    //    unchecked(x)	    在 unchecked 上下文中计算表达式
    //    default(T)	    获取类型 T 的默认值
    //    delegate {...}	匿名函数（匿名方法）

//VB    &H表示16进制，&O表示8进制
//C#    0x表示16进制【零x】

//6、C#中在struct中创建数组时，必须加fixed前缀，在使用此数据结构的函数添加unsafe， private unsafe void 
//    unsafe 关键字表示不安全上下文，该上下文是任何涉及指针的操作所必需的。
//    例如：
//      private unsafe struct Te
//      {
//      public fixed bool yee[64];
//      }
       //unsafe static void SquarePtrParam(int* p)
       //{
       //   *p *= *p;
       //}

//7、
       //byte ok = 12;
       //string ss = Convert.ToString(ok, 16);  输出的是C，即16进制字符
       //string ss = Convert.ToString(ok, 10);  输出的是10，即10进制字符
       //string ss = Convert.ToString(ok, 2);  输出的是1100，即2进制字符

       //PadLeft(Int32, Char)	返回一个新字符串，
       //该字符串通过在此实例中的字符左侧填充指定的 Unicode 字符来达到指定的总长度，
       //从而使这些字符右对齐。

//8、C#中TAB键是\t；

//9、索引器
//  索引器 (indexer) 是这样一个成员：它支持按照索引数组的方法来索引对象。
//  索引器的声明与属性类似，不同的是该成员的名称是 this，后跟一个位于定界符 [ 和 ] 之间的参数列表。
//  在索引器的访问器中可以使用这些参数。与属性类似，索引器可以是读写、只读和只写的，
//  并且索引器的访问器可以是虚的。
//  该 List 类声明了单个读写索引器，该索引器接受一个 int 参数。
//  该索引器使得通过 int 值对 List 实例进行索引成为可能。例如
//  List<string> names = new List<string>();
//  names.Add("Liz");
//  names.Add("Martha");
//  names.Add("Beth");
//  for (int i = 0; i < names.Count; i++) {
//    string s = names[i];
//    names[i] = s.ToUpper();
//  }
//  索引器可以被重载，这意味着一个类可以声明多个索引器，只要其参数的数量和类型不同即可。

//10、事件
//  事件 (event) 是一种使类或对象能够提供通知的成员。事件的声明与字段类似，
//  不同的是事件的声明包含 event 关键字，并且类型必须是委托类型。
//  在声明事件成员的类中，事件的行为就像委托类型的字段（前提是该事件不是抽象的并且未声明访问器）。
//  该字段存储对一个委托的引用，该委托表示已添加到该事件的事件处理程序。
//  如果尚未添加事件处理程序，则该字段为 null。
//  List<T> 类声明了一个名为 Changed 的事件成员，它指示已将一个新项添加到列表中。
//  Changed 事件由 OnChanged 虚方法引发，后者先检查该事件是否为 null（表明没有处理程序）。
//  “引发一个事件”与“调用一个由该事件表示的委托”这两个概念完全等效，
//  因此没有用于引发事件的特殊语言构造。
//  客户端通过事件处理程序 (event handler) 来响应事件。事件处理程序使用 += 运算符附加，
//  使用 -= 运算符移除。下面的示例向 List<string> 类的 Changed 事件附加一个事件处理程序。
//  using System;
//  class Test
//  {
//    static int changeCount;
//    static void ListChanged(object sender, EventArgs e) {
//        changeCount++;
//      }
//    static void Main() {
//        List<string> names = new List<string>();
//        names.Changed += new EventHandler(ListChanged);
//        names.Add("Liz");
//        names.Add("Martha");
//        names.Add("Beth");
//        Console.WriteLine(changeCount);		// Outputs "3"
//    }
//  }
//  对于要求控制事件的底层存储的高级情形，事件声明可以显式提供 add 和 remove 访问器，它们在某种程度上类似于属性的 set 访问器。

//11、如果需要在一个类的里面再创建一个类，而且需要将外面类的变量在里面的类进行引用，
//    则需要将外面的变量定义为【internal static】；

//12、System.Threading.Timer AutoSendTimer = new System.Threading.Timer(null);
//    可以利用此方法顶时调用某个函数进行处理；

//13、在程序中如果对公共属性【具有读写性质】进行赋值，会发生编译错误；

//14、如果在发送数据包时用到[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
//    和[StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
//    就需要引用：using System.Runtime.InteropServices;

//15、Dictionary<string, Socket> SocketDict = new Dictionary<string, Socket>();//存放套接字

//16、使用线程计时器 【System.Threading.Timer】的TimerCallback委托进行定时调用函数
    //发生错误提示：TimerCallBack不能为空
    //System.Threading.Timer AutoSendTimer = new System.Threading.Timer(null);

    //public void StartTimer(int dueTime)
    //{
    //    Timer t = new Timer(new TimerCallback(TimerProc));
    //    t.Change(dueTime, 0);
    //}

    //private void TimerProc(object state)
    //{
    //    // The state object is the Timer object.
    //    Timer t = (Timer) state;
    //    t.Dispose();
    //    Console.WriteLine("The timer callback executes.");
    //}

//17、预防一个程序多次开启运行
    //bool SoftwareAlreadyOpened = false;
    //Mutex MutexCheck = new Mutex(false, "software", out SoftwareAlreadyOpened);
    //if (!SoftwareAlreadyOpened)
    //    {
    //    MessageBox.Show("The software was already opened, you can't run another copy at the same time.\r\n出于安全考虑，不允许同时运行此软件的另外一个副本.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
    //    return;
    //    }

//18、如果不知道返回的数组大小，可以先定义一个数组，然后将返回的数组赋值给定义的数组即可；
    //这样不会报错
    //string[] y;
    //y= XML.FindInnerTextInXMLFile("data", "TestPara");

//19、为了在以太网通讯时发送以下格式的文本，可以将要发送的内容先写入文件，然后再发送除去即可；
    //<?xml version="1.0" encoding="gb2312"?>
    //<root>
    //  <ccdPara>
    //    <para>
    //      <id>0</id>
    //      <p>0</p>
    //      <dataPart>60</dataPart>
    //      <TestPara>
    //        <index>0</index>
    //        <testName>FAI 4</testName>
    //        <normal>002.390</normal>
    //        <min>0.030</min>
    //        <max>0.050</max>
    //        <pixV>0.000</pixV>
    //        <Bc>000.000</Bc>
    //      </TestPara>
    //    </para>
    //  </ccdPara>
    //  <one>
    //    <id>1087</id>
    //    <flag>NG</flag>
    //    <machineId>MachineID:001</machineId>
    //    <mould />
    //    <Date>2016/12/15 21:47:34</Date>
    //    <str>+0000000.0,+0000000.00</str>
    //  </one>
    //</root>

//20、可以通过DOS命令tasklist >d:\t.txt得到当前进程清单，然后找出对应的exe/com文件，
    //执行taskkill /F /IM 文件全名，就可以关闭相关进程

//21、在建立以太网通讯的连接时，可以添加到字典变量中，
    //System.Collections.Generic.Dictionary<string, System.Net.Sockets.TcpClient> xx = new Dictionary<string, System.Net.Sockets.TcpClient>();
    //if (xx != null) 
    //    {
    //    foreach (System.Net.Sockets.TcpClient a in xx.Values) 
    //        {
    //        //发送内容的代码部分
    //        }
    //    }

//22、使用非托管 DLL 函数
    //利用平台调用这种服务，托管代码可以调用在动态链接库 (DLL)（如 Win32 API 中的 DLL）中实现的非托管函数。
    //此服务将查找并调用导出的函数，然后根据需要跨越互用边界封送其参数（整数、字符串、数组、结构等）。
    //使用导出的 DLL 函数

    //标识 DLL 中的函数。

    //最低限度上，必须指定函数的名称和包含该函数的 DLL 的名称。

    //创建用于容纳 DLL 函数的类。

    //可以使用现有类，为每一非托管函数创建单独的类，或者创建包含一组相关的非托管函数的一个类。

    //在托管代码中创建原型。

    //[Visual Basic] 使用带 Function 和 Lib 关键字的 Declare 语句。 在某些少见的情况下，可以使用带 Shared Function 关键字的 DllImportAttribute。 这些情况在本节后面部分进行说明。

    //[C#] 使用 DllImportAttribute 标识 DLL 和函数。 用 static 和 extern 修饰符标记方法。

    //[C++] 使用 DllImportAttribute 标识 DLL 和函数。 用 extern "C" 标记包装方法或函数。

    //调用 DLL 函数。

    //像处理其他任何托管方法一样调用托管类上的方法。传递结构和 实现回调函数属于特殊情况。

//23、Marshal 类
    //提供了一个方法集，这些方法用于分配非托管内存、复制非托管内存块、将托管类型转换为非托管类型，
    //此外还提供了在与非托管代码交互时使用的其他杂项方法。
    //Marshal 类中定义的 static 方法对于处理非托管代码至关重要。 此类中定义的大多数方法通常由需要
    //在托管和非托管编程模型之间提供桥梁的开发人员使用。
    //例如， StringToHGlobalAnsi 方法将 ANSI 字符从指定的字符串（在托管堆中）复制到非托管堆中的缓冲区。
    //该方法还分配大小正确的目标堆。
    //Marshal 类中的 Read 和 Write 方法支持对齐和未对齐的访问。


//24、在一个窗体中同一个区域显示不同窗体或者控件，使用panel控件；
    //先将需要操作的对象窗体或者控件添加到panel控件中，然后再设置此控件对应子项的Hide属性
    //例如在一个窗体的panel控件中添加窗体：
    //form1.TopLevel=false;
    //panelControls.Add(form1);
    //form1.size=panel1.size;
    //form1.mainForm = this;
    //form1.Hide();
    //将所有需要的窗体全部按照上述方式添加至panel后，就可以视需要将某个窗体Show();

//25、FileDialog .Filter 属性(OPEN/SAVE)
    //获取或设置当前文件名筛选器字符串，该字符串决定对话框的“另存为文件类型”或“文件类型”框中出现的选择内容。
    //对于每个筛选选项，筛选器字符串都包含筛选器说明，后接一垂直线条 (|) 和筛选器模式。不同筛选选项的字符串由垂直线条隔开。

    //下面是一个筛选器字符串的示例：
    //Text files (*.txt)|*.txt|All files (*.*)|*.*

    //通过使用分号来分隔文件类型，可将多个筛选器模式添加到筛选器中，例如：
    //Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*

    //使用 FilterIndex【第一个筛选器条目的索引值为 1】 属性设置第一个显示给用户的筛选选项。

//26、

#endregion

namespace PengDongNanTools
    {
    class 重要提示
        {

        /// <summary>
        /// 提示信息
        /// </summary>
        public string ErrorMessage = "";

        private bool SuccessBuiltNew = false, PasswordIsCorrect = false;

        /// <summary>
        /// 软件作者
        /// </summary>
        public string Author
            {
            get { return "【软件作者：彭东南, southeastofstar@163.com】"; }
            }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DLLPassword">使用此DLL的密码</param>
        public 重要提示(string DLLPassword)
            {

            SuccessBuiltNew = false;
            PasswordIsCorrect = false;

            try
                {

                if (DLLPassword == "ThomasPeng" || (DLLPassword == "pengdongnan") 
                    || (DLLPassword == "彭东南"))
                    {
                    PasswordIsCorrect = true;
                    SuccessBuiltNew = true;
                    }
                else
                    {
                    PasswordIsCorrect = false;
                    SuccessBuiltNew = false;
                    MessageBox.Show("Right Prohibited.\return\n     You don't have the given right to use this DLL library, please contact with ThomasPeng.\r\n你未得到授权的密码，无法使用此DLL进行软件开发！请与作者彭东南联系：southeastofstar@163.com\r\n                                                                版权所有： 彭东南", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                    }

                }
            catch (Exception ex)
                {
                SuccessBuiltNew = false;
                MessageBox.Show("创建类的实例时出现错误！\r\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
                }
            
            }
        
        //System.Windows.Forms.Control xx;
        //System.Windows.Forms.Button aa = new Button();
        //xx = aa;

        //System.Collections.Generic.Dictionary<string, System.Net.Sockets.TcpClient> xx = new Dictionary<string, System.Net.Sockets.TcpClient>();
        //if (xx != null) 
        //    {
        //    foreach (System.Net.Sockets.TcpClient a in xx.Values) 
        //        {
        //        //发送内容的代码部分
        //        }
        //    }

        public int Test()
            {
            try
                {


                int Return = 0;

                return Return;
                }
            catch (Exception ex)
                {
                ErrorMessage = ex.Message;
                return 1;
                }
            }
        
        #region ""



        #endregion

        //数据包结构体
        /// <summary>
        /// 数据包结构体
        /// </summary>
        [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        public struct Package
            {
            /// <summary>
            /// 确定为命令包的标识
            /// </summary>
            public int commandFlag;
            /// <summary>
            /// 命令
            /// </summary>
            public int command;
            /// <summary>
            ///数据长度（数据段不包括包头）
            /// </summary>
            public int dataLength;
            /// <summary>
            /// 通道编号
            /// </summary>
            public short channelNo;
            /// <summary>
            /// 块编号
            /// </summary>
            public short blockNo;
            /// <summary>
            /// 开始标记
            /// </summary>
            public int startFlag;
            /// <summary>
            /// 结束标记0x0D0A为结束符
            /// </summary>
            public int finishFlag;
            /// <summary>
            /// 校验码
            /// </summary>
            public int checksum;
            /// <summary>
            /// 保留 char数组，SizeConst表示数组个数，在转成
            /// byte数组前必须先初始化数组，再使用，初始化
            /// 的数组长度必须和SizeConst一致，例：test=new char[4];
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public char[] reserve;
            }

        //Byte数组转结构体
        /// <summary>
        /// Byte数组转结构体
        /// </summary>
        /// <param name="bytes">byte数组</param>
        /// <param name="type">结构体类型</param>
        /// <returns>转换后的结构体</returns>
        public static object BytesToStuct(byte[] bytes, Type type)
            {
            //得到结构体的大小
            int size = Marshal.SizeOf(type);
            //byte数组长度小于结构体的大小
            if (size > bytes.Length)
            { return null; }
            IntPtr structPtr = Marshal.AllocHGlobal(size);
            Marshal.Copy(bytes, 0, structPtr, size);
            object obj = Marshal.PtrToStructure(structPtr, type);
            //释放内存空间
            Marshal.FreeHGlobal(structPtr);
            return obj;
            }

        }//class
    }//namespace
