﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//函数导入及注释在VB里面有写过，找一下

namespace PengDongNanTools
    {
    class KeyenceLJ_Laser
        {
        }
    }
