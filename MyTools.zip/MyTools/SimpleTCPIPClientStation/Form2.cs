﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PengDongNanTools;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using Microsoft.VisualBasic;

namespace PengDongNanTools
    {

    public partial class Form2 : Form
        {
        public Form2()
            {
            InitializeComponent();
            }

        //TCPIPAsyncServer pp;
        //TCPIPAsyncClient ss;
        //TcpClient cc;
        CommonFunction FC = new CommonFunction("彭东南");
        XMLOperation XML = new XMLOperation("彭东南");

        Delay Delay1 = new Delay("彭东南");

        System.Threading.Thread TheadTest = null;

        private void Form2_Load(object sender, EventArgs e)
            {
            //pp = new TCPIPAsyncServer(8000, 5, ref this.richTextBox1, "彭东南");
            //ss = new TCPIPAsyncClient("localhost", 8000, ref this.richTextBox1, "彭东南");
            //cc = new TcpClient("localhost", 8000);
            //string[] aa = { "987645123" };

            //ss.AutoSendInterval = 1000;
            //ss.SendMessage = aa;
            //ss.AutoSend = true;

            //string[] xt = { "1" };//+ System.DateTime.Now };
            //pp.SendMessage = xt;

            //pp.AutoSend = true;




            }
        int x = 0;
        string[] y;
        private void button1_Click(object sender, EventArgs e)
            {
            ////截屏
            //Bitmap tt = new Bitmap(1024, 768);
            //Graphics dd = Graphics.FromImage(tt);
            //dd.CopyFromScreen(0,0,0,0,new Size(1024,768));
            //tt.Save("e:\\aa.bmp");

            //FC.ScreenShot();

            byte a = new byte();
            a = 100;

            richTextBox1.AppendText(FC.ConvertByteToBinaryStringFormat(a) + "\r\n");
            richTextBox1.AppendText(FC.ConvertByteToHexStringFormat(a) + "\r\n");

            richTextBox1.AppendText(FC.ConvertIntToBinaryStringFormat(65535) + "\r\n");
            richTextBox1.AppendText(FC.ConvertIntToHexStringFormat(65535) + "\r\n");

            panel1.Controls.Add(this.richTextBox1);
            panel1.Controls.Add(this.richTextBox2);

            //richTextBox1.AppendText(panel1.);

            //richTextBox1.AppendText(DateTime.Now.ToString() + "  " + DateTime.Now.Millisecond + "\r\n");

            if (TheadTest == null)
                {
                TheadTest = new System.Threading.Thread(ChangePos);
                TheadTest.IsBackground = true;
                TheadTest.Start();
                }

            Delay1.Start();

            richTextBox1.AppendText(Delay1.ErrorMessage + "\r\n");

            Temps = false;

            //richTextBox1.AppendText(XML.OpenXMLFile("data").ToString());

            //XML.ClearDataRecordsInXMLFile("e:\\data");
            //XML.DelDataRecordsInXMLFile("data", "TestPara");

            //y= XML.FindInnerTextInXMLFile("data", "TestPara");

            //for (int a = 0; a < y.Length; a++) 
            //    {
            //    richTextBox1.AppendText(y[a] + "\r\n");
            //    }

            //x += 1;
            //y = new string[x];

            //for (int a = 0; a < y.Length; a++) 
            //    {
            //    y[a] = a.ToString();// +" - " + DateTime.Now;
            //    }
            //if (ss != null) 
            //    {
            //    ss.SendMessage = y;
            //    ss.SendMessage = y;
            //    }
            }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
            {
            //if (pp != null)
            //    {
            //    pp.Close();
            //    pp = null;
            //    }

            //if (ss != null)
            //    {
            //    ss.Close();
            //    ss = null;
            //    }

            //if (cc != null)
            //    {
            //    cc.Close();
            //    cc = null;
            //    }
            FC.Dispose();
            XML.Dispose();
            TheadTest = null;

            }

        string[] Temp = null;
        
        private void timer1_Tick(object sender, EventArgs e)
            {
            //if (pp != null) 
            //    {
            //    //this.richTextBox2.Text = "";
            //    string str = "";
            //    if (pp.ConnectedClients.Length > 0) 
            //        {
            //        for (int a = 0; a < pp.ConnectedClients.Length; a++)
            //            {
            //            str = str + pp.ConnectedClients[a] + "\r\n";
            //            }
            //        this.richTextBox2.Text = str;
            //        }

                //Temp = new string[pp.ConnectedClients.Length];
                

                //}

            //if (cc != null) 
            //    {
            //    this.richTextBox2.AppendText(FC.GetRemoteIP(cc) + " " + FC.GetRemotePort(cc).ToString() + "\r\n");
            //    }
            }

        private void button3_Click(object sender, EventArgs e)
            {
            //if (pp == null) 
            //    {
            //    pp = new TCPIPAsyncServer(8000, 5, ref this.richTextBox1, "彭东南");
            //    pp.AutoSend = true;
            //    }

            //if (ss == null)
            //    {
            //    ss = new TCPIPAsyncClient("localhost", 8000, ref this.richTextBox1, "彭东南");
            //    }  
            //if (cc == null)
            //    {
            //    cc = new TcpClient("localhost", 8000);
            //    }
            }

        private void button2_Click(object sender, EventArgs e)
            {
            
            richTextBox1.AppendText("A的ASCII码是" + Strings.Asc("A") + "\r\n");
            richTextBox1.AppendText("Z的ASCII码是" + Strings.Asc("Z") + "\r\n");

            richTextBox1.AppendText(x.ToString() + "\r\n");

            richTextBox1.AppendText(Strings.Format(FC.GetDriveFreeSpaceInMB('F'), "##########.##") + "\r\n");
            richTextBox1.AppendText(Strings.Format(FC.GetDriveFreeSpaceInMB('F')/1024, "##########.##") + "\r\n");
            richTextBox1.AppendText(FC.ErrorMessage + "\r\n");

            //if (pp != null) 
            //    {
            //    pp.Close();
            //    pp = null;
            //    }

            //if (ss != null)
            //    {
            //    ss.Close();
            //    ss = null;
            //    }

            //if (cc != null)
            //    {
            //    cc.Close();
            //    cc = null;
            //    }
            }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
            {
            if (checkBox1.Checked == true)
                {
                this.richTextBox1.Visible = true;
                }
            else 
                {
                this.richTextBox1.Visible = false;
                }
            }

        bool Temps = false;
        private void ChangePos() 
            {

            int x = 1, y = 0;
            x = button2.Left;
            y = button2.Top;
            Control xx = button2;

            bool reset = false;
            
            while (true)
                {
                try
                    {



                    FC.ChangeControlText(ref xx, Delay1.PassedTime.ToString());

                    //FC.ChangeControlEnableStatus(ref xx, Delay1.Wait(2.5));//Delay1.Wait(2.5,true));

                    if (Temps == false && Delay1.Wait(2.5, true))//Delay1.Wait(2.5))
                        {
                        FC.AddRichText(ref richTextBox1, Delay1.PassedTime.ToString());
                        //Delay1.Reset();
                        //Delay1.Start();
                        reset = true;
                        Temps = true;
                        }

                    if (reset == true) 
                        {
                        //Delay1.Reset();
                        Delay1.Start();
                        reset = false;
                        Temps = false;
                        }

                    //xx = button2;
                    //FC.ChangeControlPosition(ref xx, x, y);
                    //System.Threading.Thread.Sleep(1000);
                    //x += 11;
                    //y += 10;

                    //if (x / 10 % 2 == 1)
                    //    {
                    //    FC.ChangeControlBackColor(ref xx, Color.Red);
                    //    FC.ChangeControlEnableStatus(ref xx, true); 
                    //    FC.ChangeControlForeColor(ref xx, Color.Yellow);
                    //    FC.ChangeControlText(ref xx, x.ToString());
                    //    }
                    //else 
                    //    {
                    //    FC.ChangeControlBackColor(ref xx, Color.Green); 
                    //    FC.ChangeControlEnableStatus(ref xx, false);
                    //    FC.ChangeControlForeColor(ref xx, Color.Blue);
                    //    FC.ChangeControlText(ref xx, y.ToString());
                    //    }

                    //xx = button3;
                    //FC.ChangeControlPosition(ref xx, x+20, y+30);
                    //if (x / 10 % 2 == 1)
                    //    {
                    //    FC.ChangeControlBackColor(ref xx, Color.Red);
                    //    FC.ChangeControlEnableStatus(ref xx, true);
                    //    FC.ChangeControlForeColor(ref xx, Color.Yellow);
                    //    FC.ChangeControlText(ref xx, x.ToString());
                    //    }
                    //else
                    //    {
                    //    FC.ChangeControlBackColor(ref xx, Color.Green);
                    //    FC.ChangeControlEnableStatus(ref xx, false);
                    //    FC.ChangeControlForeColor(ref xx, Color.Blue);
                    //    FC.ChangeControlText(ref xx, y.ToString());
                    //    }
                    }
                catch (Exception ex)
                    {
                    FC.AddRichText(ref richTextBox1, ex.Message);
                    }
                }
            }

        }
    }
